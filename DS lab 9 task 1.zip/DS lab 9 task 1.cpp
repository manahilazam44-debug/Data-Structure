#include<iostream>
using namespace std;

const int SIZE = 5;  
int queue[SIZE];
int front=0, rear=0;  
int count=0;           

void enQueue(int value){
    if(count == SIZE){
        cout<<"Queue is full!\n";
        return;
    }
    queue[rear]=value;
    rear++;
    count++;
    cout<<"Enqueued: "<<value<<endl;
}

void deQueue(){
    if(count == 0){
        cout<<"Queue is empty!\n";
        return;
    }
    cout<<"Dequeued: "<<queue[front]<<endl;
    front++;
    count--;
}

void display(){
    if(count == 0){
        cout<<"Queue is empty!\n";
        return;
    }
    cout<<"Queue elements: ";
    for(int i=front; i<rear; i++) {
        cout<<queue[i]<<" ";
    }
    cout<<endl;
}
void countElements(){
    cout<<"Number of elements in queue: "<<count<<endl;
}

int main(){
    int choice, value;
    do {
        cout<<"\nMenu:\n1. Enqueue\n2. Dequeue\n3. Display\n4. Count Elements\n5. Exit\nEnter choice: ";
        cin>>choice;

        switch(choice){
            case 1:
                cout<<"Enter value to enqueue: ";
                cin>>value;
                enQueue(value);
                break;
            case 2:
                deQueue();
                break;
            case 3:
                display();
                break;
            case 4:
                countElements();
                break;
            case 5:
                cout<<"Exiting program\n";
                break;
            default:
                cout<<"Invalid choice! Try again.\n";
        }
    } while(choice!=5);

    return 0;
}