#include <iostream>
using namespace std;

struct Node{
    int data;
    Node* next;
};

Node* front=nullptr;
Node* rear=nullptr;

void enQueue(int value) {
    Node* temp = new Node();
    temp->data = value;
    temp->next = nullptr;
    if (rear == nullptr) { 
        front = rear = temp;
    } 
	else{
        rear->next = temp;
        rear = temp;
    }
    cout<<"Enqueued: "<<value<<endl;
}


void deQueue(){
    if (front == nullptr){
        cout<<"Queue is empty!\n";
        return;
    }
    Node* temp = front;
    cout<<"Dequeued: "<<temp->data<<endl;
    front = front->next;
    if (front == nullptr) rear = nullptr; 
    delete temp;
}


void display(){
    if (front == nullptr){
        cout<<"Queue is empty!\n";
        return;
    }
    cout<<"Queue elements: ";
    Node* temp = front;
    while(temp != nullptr) {
        cout<<temp->data <<" ";
        temp = temp->next;
    }
    cout<<endl;
}

void countElements(){
    int count = 0;
    Node* temp = front;
    while (temp != nullptr) {
        count++;
        temp = temp->next;
    }
    cout<<"Number of elements: "<<count<<endl;
}

int main(){
    int choice, value;
    do{
        cout<<"\nMenu:\n1. Enqueue\n2. Dequeue\n3. Display\n4. Count Elements\n5. Exit\nEnter choice: ";
        cin>>choice;

        switch(choice){
            case 1:
                cout<<"Enter value to enqueue: ";
                cin>>value;
                enQueue(value);
                break;
            case 2:
                deQueue();
                break;
            case 3:
                display();
                break;
            case 4:
                countElements();
                break;
            case 5:
                cout<<"Exiting program\n";
                break;
            default:
                cout<<"Invalid choice! Try again.\n";
        }
    } while(choice!=5);

    return 0;
}