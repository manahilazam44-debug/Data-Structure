#include <iostream>
using namespace std;

const int SIZE =5;
int queue[SIZE];
int front=0, rear=0;  
int count=0;            

void enQueue(int value){
    if(count==SIZE){
        cout<<"Queue is full! Cannot insert "<<value<<endl;
        return;
    }
    queue[rear] =value;
    rear++;    
    count++;   
    cout<<"Enqueued: "<<value<<endl;
}

void deQueue(){
    if(count==0){
        cout<<"Queue is empty! Cannot dequeue."<<endl;
        return;
    }
    cout<<"Dequeued: "<<queue[front]<<endl;
    front++;     
    count--;    
}

void printQueue(){
    cout<<"Queue Array: ";
    if(count==0){
        cout<<"Empty";
    } 
	else{
        for(int i=front; i<rear; i++) {
            cout<<queue[i]<<" ";
        }
    }
    cout<<"\nFront index: "<<front<<", Rear index: "<<rear<<"\n\n";
}

int main() {
    enQueue(10); printQueue();
    enQueue(20); printQueue();
    enQueue(30); printQueue();
    deQueue();   printQueue();
    enQueue(40); printQueue();
    enQueue(50); printQueue();
    enQueue(60); printQueue();  

    return 0;
}