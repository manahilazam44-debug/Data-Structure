#include<iostream>
using namespace std;

struct node
{
    string name;
    int score;
    node *next;
    node *prev;
};

node *head=NULL;

void addPlayer()
{
    node *newnode=new node;

    cout<<"Enter player name: ";
    cin>>newnode->name;

    cout<<"Enter score: ";
    cin>>newnode->score;

    newnode->next=NULL;
    newnode->prev=NULL;

    if(head==NULL)
    {
        head=newnode;
        return;
    }

    node *temp=head;

    while(temp->next!=NULL && temp->score < newnode->score)
        temp=temp->next;

    if(newnode->score < head->score)
    {
        newnode->next=head;
        head->prev=newnode;
        head=newnode;
    }
    else
    {
        newnode->next=temp->next;
        newnode->prev=temp;

        if(temp->next!=NULL)
            temp->next->prev=newnode;

        temp->next=newnode;
    }
}

void deletePlayer()
{
    string name;
    cout<<"Enter player name to delete: ";
    cin>>name;

    node *temp=head;

    while(temp!=NULL)
    {
        if(temp->name==name)
        {
            if(temp==head)
            {
                head=head->next;
                if(head!=NULL)
                    head->prev=NULL;
            }
            else
            {
                temp->prev->next=temp->next;

                if(temp->next != NULL)
                    temp->next->prev=temp->prev;
            }

            delete temp;
            cout<<"Player deleted\n";
            return;
        }

        temp=temp->next;
    }

    cout<<"Player not found\n";
}

void display()
{
    node *temp = head;

    cout<<"\nPlayers List\n";

    while(temp!=NULL)
    {
        cout<<temp->name<<"  "<<temp->score<<endl;
        temp=temp->next;
    }
}

void lowestScore()
{
    if(head==NULL)
        return;

    cout<<"Lowest Score Player: "<<head->name<<" "<<head->score<<endl;
}

void sameScore()
{
    int s;
    cout<<"Enter score: ";
    cin>>s;

    node *temp=head;

    while(temp!=NULL)
    {
        if(temp->score==s)
            cout<<temp->name<<" "<<temp->score<<endl;

        temp=temp->next;
    }
}

void backward()
{
    string name;
    cout<<"Enter player name: ";
    cin>>name;

    node *temp=head;

    while(temp!=NULL)
    {
        if(temp->name==name)
        {
            temp=temp->prev;

            while(temp!=NULL)
            {
                cout<<temp->name<<" "<<temp->score<<endl;
                temp=temp->prev;
            }

            return;
        }

        temp=temp->next;
    }

    cout<<"Player not found\n";
}

int main()
{
    int choice;

    while(true)
    {
        cout<<"\n1 Add Player";
        cout<<"\n2 Delete Player";
        cout<<"\n3 Display Players";
        cout<<"\n4 Lowest Score Player";
        cout<<"\n5 Players with Same Score";
        cout<<"\n6 Display Backward From Player";
        cout<<"\n7 Exit"<<endl;

        cin>>choice;

        switch(choice)
        {
            case 1: addPlayer(); 
			break;
			
            case 2: deletePlayer();
		    break;
            case 3: display(); 
			break;
			
            case 4: lowestScore(); 
			break;
			
            case 5: sameScore(); 
			break;
            
			case 6: backward();
		    break;
		    
            case 7: 
			return 0;
        }
    }
}