#include<iostream>
using namespace std;

struct node
{
    int data;
    node *next;
    node *prev;
};

node *head = NULL;

void create()
{
    node *temp, *newnode;
    int value;

    for(int i=1; i<=7; i++)
    {
        newnode=new node;

        cout<<"Enter rainfall for day "<<i<<": ";
        cin>>value;

        while(value<0)
        {
            cout<<"Negative rainfall not allowed. Enter again: ";
            cin>>value;
        }

        newnode->data=value;
        newnode->next=NULL;
        newnode->prev=NULL;

        if(head==NULL)
        {
            head=newnode;
            temp=newnode;
        }
        else
        {
            temp->next=newnode;
            newnode->prev=temp;
            temp=newnode;
        }
    }
}

void calculate()
{
    node *temp=head;
    int total=0;
    int highest, lowest;
    int day=1, highDay=1, lowDay=1;

    if(temp!=NULL)
    {
        highest=lowest=temp->data;
    }

    while(temp!=NULL)
    {
        total=total+temp->data;

        if(temp->data > highest)
        {
            highest=temp->data;
            highDay=day;
        }

        if(temp->data < lowest)
        {
            lowest=temp->data;
            lowDay=day;
        }

        temp=temp->next;
        day++;
    }

    cout<<"Total rainfall = "<<total<<endl;
    cout<<"Average rainfall = "<<total/7.0<<endl;

    cout<<"Highest rainfall on day "<<highDay<<" = "<<highest<<endl;
    cout<<"Lowest rainfall on day "<<lowDay<<" = "<<lowest<<endl;
}

void after5th()
{
    node *temp=head;
    int count=1;

    while(temp!=NULL && count<6)
    {
        temp=temp->next;
        count++;
    }

    if(temp!=NULL)
        cout<<"Rainfall after 5th node (Day 6) = "<<temp->data<<endl;
    else
        cout<<"No node after 5th"<<endl;
}

int main()
{
    create();

    calculate();

    after5th();

    return 0;
}