#include<iostream>
using namespace std;

struct node
{
    int data;
    node *next;
    node *prev;
};

node *head=NULL;

void create()
{
    node *temp, *newnode;
    int n, value;

    cout<<"Enter number of nodes: ";
    cin>>n;

    for(int i=0;i<n;i++)
    {
        newnode=new node;
        cout<<"Enter marks: ";
        cin>>value;

        newnode->data = value;
        newnode->next = NULL;
        newnode->prev = NULL;

        if(head==NULL)
        {
            head=newnode;
            temp=newnode;
        }
        else
        {
            temp->next=newnode;
            newnode->prev=temp;
            temp=newnode;
        }
    }
}

void addBeginning()
{
    node *newnode;
    int value;

    cout<<"Enter value to insert at beginning: ";
    cin>>value;

    newnode=new node;
    newnode->data=value;

    newnode->next=head;
    newnode->prev=NULL;

    if(head!=NULL)
        head->prev=newnode;

    head=newnode;
}

void addAfter45()
{
    node *temp;
    int value;

    cout<<"Enter value to insert after 45: ";
    cin>>value;

    temp=head;

    while(temp!=NULL)
    {
        if(temp->data==45)
        {
            node *newnode=new node;

            newnode->data=value;
            newnode->next=temp->next;
            newnode->prev=temp;

            if(temp->next!=NULL)
                temp->next->prev=newnode;

            temp->next=newnode;
            break;
        }

        temp=temp->next;
    }
}

void deleteBeginning()
{
    node *temp;

    if(head==NULL)
    {
        cout<<"List empty\n";
        return;
    }

    temp=head;
    head=head->next;

    if(head!=NULL)
        head->prev=NULL;

    delete temp;
}


void deleteAfter45()
{
    node *temp=head;

    while(temp!=NULL)
    {
        if(temp->data==45 && temp->next!=NULL)
        {
            node *del=temp->next;

            temp->next=del->next;

            if(del->next!=NULL)
                del->next->prev=temp;

            delete del;
            break;
        }

        temp=temp->next;
    }
}

void display()
{
    node *temp=head;

    cout<<"List: ";

    while(temp!=NULL)
    {
        cout<<temp->data<<" ";
        temp=temp->next;
    }

    cout<<endl;
}

int main()
{
    create();
    display();

    addBeginning();
    display();

    addAfter45();
    display();

    deleteBeginning();
    display();

    deleteAfter45();
    display();

    return 0;
}