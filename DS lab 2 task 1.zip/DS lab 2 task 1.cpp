#include<iostream>
using namespace std;
int main(){
	
	int arr[5]={4,5,6,7,8};
	int *ptr= arr;
	
	cout<<"Array elements: "<<endl;
	for(int i=0; i<5; i++){
		cout<<*(ptr + i)<<" ";
	}
	
	return 0;
}