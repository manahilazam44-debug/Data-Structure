#include <iostream>
using namespace std;

struct Node
{
    string name;
    Node* next;
};

Node* head=NULL;

void addEmployee(string name)
{
    Node* newNode=new Node;
    newNode->name=name;

    if(head==NULL)
    {
        head=newNode;
        newNode->next=head;
    }
    else
    {
        Node* temp=head;
        while(temp->next!=head)
        {
            temp=temp->next;
        }
        temp->next=newNode;
        newNode->next=head;
    }

    cout<<"Employee added successfully\n";
}


void searchEmployee(string name)
{
    if (head==NULL)
    {
        cout<<"List is empty\n";
        return;
    }

    Node* temp=head;

    do
    {
        if(temp->name==name)
        {
            cout<<"Employee found successfully\n";
            return;
        }
        temp=temp->next;
    } 
    while(temp!=head);

    cout<<"Employee not found\n";
}


void updateEmployee(string oldName, string newName)
{
    if(head==NULL)
    {
        cout<<"List is empty\n";
        return;
    }

    Node* temp=head;

    do
    {
        if(temp->name==oldName)
        {
            temp->name=newName;
            cout<<"Employee updated successfully\n";
            return;
        }
        temp=temp->next;
    } 
    while(temp!=head);

    cout<<"Employee not found\n";
}


void deleteEmployee(string name)
{
    if(head==NULL)
    {
        cout<<"List is empty\n";
        return;
    }

    Node *temp=head, *prev=NULL;

    if(head->name==name)
    {
        Node* last=head;
        while(last->next!=head)
        {
            last=last->next;
        }

        if(head->next==head)
        {
            delete head;
            head = NULL;
        }
        else
        {
            last->next=head->next;
            Node* del=head;
            head=head->next;
            delete del;
        }

        cout<<"Employee deleted successfully\n";
        return;
    }

    prev=head;
    temp=head->next;

    while(temp!=head && temp->name!=name)
    {
        prev=temp;
        temp=temp->next;
    }

    if(temp==head)
    {
        cout<<"Employee not found\n";
    }
    else
    {
        prev->next=temp->next;
        delete temp;
        cout<<"Employee deleted successfully\n";
    }
}


void display()
{
    if (head==NULL)
    {
        cout<<"No employees\n";
        return;
    }

    Node* temp=head;

    do
    {
        cout<<temp->name<<endl;
        temp=temp->next;
    } 
    while(temp!=head);
}

int main()
{
    int choice;
    string name, newName;

    do
    {
        cout<<"\n1. Add Employee\n";
        cout<<"2. Delete Employee\n";
        cout<<"3. Update Employee\n";
        cout<<"4. Search Employee\n";
        cout<<"5. Display Employees\n";
        cout<<"6. Exit\n";
        cout<<"Enter choice: ";
        cin>>choice;

        switch(choice)
        {
            case 1:
                cout<<"Enter name: ";
                cin>>name;
                addEmployee(name);
                break;

            case 2:
                cout<<"Enter name to delete: ";
                cin>>name;
                deleteEmployee(name);
                break;

            case 3:
                cout<<"Enter old name: ";
                cin>>name;
                cout<<"Enter new name: ";
                cin>>newName;
                updateEmployee(name, newName);
                break;

            case 4:
                cout<<"Enter name to search: ";
                cin>>name;
                searchEmployee(name);
                break;

            case 5:
                display();
                break;
        }

    } while(choice!=6);

    return 0;
}