#include <iostream>
using namespace std;

class Book
{
private:
    string bookId;
    string bookName;
    double bookPrice;
    string bookAuthor;
    string bookISBN;

public:
    Book(){}

    Book(string id, string name, double price, string author, string isbn)
    {
        bookId=id;
        bookName=name;
        bookPrice=price;
        bookAuthor=author;
        bookISBN=isbn;
    }

   
    string getId(){ 
	return bookId; 
	}
	
    string getName(){ 
	return bookName;
}

    double getPrice(){ 
	return bookPrice;
}
	 
    string getAuthor(){
	 return bookAuthor;
}
	  
    string getISBN(){ 
	return bookISBN;
}
	 

 
    void setName(string name){ 
	bookName = name; 
}

    void setPrice(double price){ 
	bookPrice = price;
}

    void setAuthor(string author){ 
	bookAuthor = author; 
}

    void setISBN(string isbn){ 
	bookISBN = isbn;
}

};

class Node
{
private:
    Book book;
    Node* next;
    Node* prev;

public:
    Node()
    {
        next=NULL;
        prev=NULL;
    }

    Node(Book b)
    {
        book=b;
        next=NULL;
        prev=NULL;
    }

    Book getBook(){
	 return book;
}
    void setBook(Book b){ 
	book = b;
}

    Node* getNext(){ 
	return next;
}

    Node* getPrev(){
	 return prev;
}

    void setNext(Node* n){ 
	next = n;
}
    void setPrev(Node* p){
	 prev = p; 
}
};

class BookList
{
private:
    Node* head;

public:
    BookList()
    {
        head=NULL;
    }

    void addBook(string id, string name, double price, string author, string isbn)
    {
        Book b(id, name, price, author, isbn);
        Node* newNode=new Node(b);

        if(head==NULL)
        {
            head=newNode;
            head->setNext(head);
            head->setPrev(head);
        }
        else
        {
            Node* last=head->getPrev();

            last->setNext(newNode);
            newNode->setPrev(last);

            newNode->setNext(head);
            head->setPrev(newNode);
        }
    }

    void removeBook(string id)
    {
        if(head==NULL)
        {
            cout<<"List is empty\n";
            return;
        }

        Node* temp=head;

        do
        {
            if (temp->getBook().getId()==id)
            {
                if (temp==head && head->getNext()==head)
                {
                    delete head;
                    head=NULL;
                }
                else
                {
                    Node* p=temp->getPrev();
                    Node* n=temp->getNext();

                    p->setNext(n);
                    n->setPrev(p);

                    if (temp==head)
                        head=n;

                    delete temp;
                }

                cout<<"Book deleted successfully\n";
                return;
            }

            temp=temp->getNext();

        } while(temp!=head);

        cout<<"Book ID not found\n";
    }

    void updateBook(string id, string name, double price, string author, string isbn)
    {
        if(head==NULL)
        {
            cout<<"List is empty\n";
            return;
        }

        Node* temp=head;

        do
        {
            if(temp->getBook().getId()==id)
            {
                Book b=temp->getBook();
                b.setName(name);
                b.setPrice(price);
                b.setAuthor(author);
                b.setISBN(isbn);

                temp->setBook(b);

                cout<<"Book updated successfully\n";
                return;
            }

            temp=temp->getNext();

        } while(temp!=head);

        cout<<"Book ID not found\n";
    }

    void printBooks()
    {
        if(head==NULL)
        {
            cout<<"No books\n";
            return;
        }

        Node* temp=head;

        do
        {
            Book b=temp->getBook();

            cout<<"ID: "<<b.getId()<<endl;
            cout<<"Name: "<<b.getName()<<endl;
            cout<<"Price: "<<b.getPrice()<<endl;
            cout<<"Author: "<<b.getAuthor()<<endl;
            cout<<"ISBN: " <<b.getISBN()<<endl;
            cout<<"-------------------\n";

            temp=temp->getNext();

        } while(temp!=head);
    }

    void printBook(string id)
    {
        if (head==NULL)
        {
            cout<<"List empty\n";
            return;
        }

        Node* temp=head;

        do
        {
            if(temp->getBook().getId()==id)
            {
                Book b=temp->getBook();

                cout<<"ID: "<< b.getId()<<endl;
                cout<<"Name: "<< b.getName()<<endl;
                cout<<"Price: "<< b.getPrice()<<endl;
                cout<<"Author: "<< b.getAuthor()<<endl;
                cout<<"ISBN: "<< b.getISBN()<<endl;

                return;
            }

            temp=temp->getNext();

        } while(temp!=head);

        cout<<"Book not found\n";
    }
};

int main()
{
    BookList list;


    list.addBook("B1","C++",500,"Ali","111");
    list.addBook("B2","Java",600,"Sara","222");
    list.addBook("B3","Python",700,"Ahmed","333");
    list.addBook("B4","DSA",800,"Zara","444");
    list.addBook("B5","AI",900,"Usman","555");
    list.addBook("B6","DBMS",550,"Ayesha","666");
    list.addBook("B7","OS",650,"Bilal","777");
    list.addBook("B8","Networks",750,"Hina","888");
    list.addBook("B9","ML",850,"Omar","999");
    list.addBook("B10","Cloud",950,"Noor","101");

    cout<<"\nAll Books\n";
    list.printBooks();

    cout << "\nPrint one Book\n";
    list.printBook("B3");

   
    list.removeBook("B5");   
    list.removeBook("B20"); 

    cout << "\nBooks after deletion\n";
    list.printBooks();

   
    list.updateBook("B3","Advanced Python",1000,"Ahmed Ali","3333");

    cout<<"\nAfter Update\n";
    list.printBook("B3");

    return 0;
}