#include <iostream>
using namespace std;
struct Node
{
    int data;
    Node* next;
};

Node* head=NULL;

void InsertBefore(int value)
{
    Node* newNode=new Node;
    newNode->data=value;

    if(head==NULL)
    {
        head=newNode;
        newNode->next=head;
    }
    else
    {
        Node* temp=head;

        while(temp->next!=head)
        {
            temp=temp->next;
        }

        newNode->next=head;
        temp->next=newNode;
        head=newNode;
    }
}


void InsertAfter(int value)
{
    Node* newNode=new Node;
    newNode->data=value;

    if(head==NULL)
    {
        head=newNode;
        newNode->next=head;
    }
    else
    {
        Node* temp=head;

        while(temp->next!=head)
        {
            temp=temp->next;
        }

        temp->next=newNode;
        newNode->next=head;
    }
}


void Delete(int value)
{
    if (head==NULL)
    {
        cout<<"List is empty\n";
        return;
    }

    Node *temp=head, *prev=NULL;

    if(head->data==value)
    {
        Node* last=head;

        while(last->next!=head)
        {
            last=last->next;
        }

        if(head->next==head)
        {
            delete head;
            head=NULL;
        }
        else
        {
            last->next=head->next;
            Node* del=head;
            head=head->next;
            delete del;
        }
        return;
    }

    prev=head;
    temp=head->next;

    while(temp!=head && temp->data!=value)
    {
        prev=temp;
        temp=temp->next;
    }

    if (temp==head)
    {
        cout<<"Value not found\n";
    }
    else
    {
        prev->next=temp->next;
        delete temp;
    }
}


void Display()
{
    if (head==NULL)
    {
        cout<<"List is empty\n";
        return;
    }

    Node* temp=head;

    do
    {
        cout<<temp->data<<" ";
        temp=temp->next;
    }
    while(temp!=head);

    cout<<endl;
}

int main()
{
    InsertBefore(10);
    InsertBefore(5);
    InsertAfter(20);
    InsertAfter(30);

    cout<<"Circular List: ";
    Display();

    Delete(20);

    cout<<"After Deletion: ";
    Display();

    return 0;
}