#include <iostream>
using namespace std;

class Inventory
{
private:
    int serialNum;
    int manufactYear;
    int lotNum;

public:

    void setData(int s, int y, int l)
    {
        serialNum=s;
        manufactYear=y;
        lotNum=l;
    }

   
    void display()
    {
        cout<<"Serial Number: "<<serialNum<<endl;
        cout<<"Manufacture Year: "<<manufactYear<<endl;
        cout<<"Lot Number: "<<lotNum<<endl;
    }
};

class Stack
{
private:
    struct Node
    {
        Inventory part;
        Node* next;
    };

    Node* top;

public:
    Stack()
    {
        top=NULL;
    }

    // push
    void push(Inventory obj)
    {
        Node* newNode=new Node;
        newNode->part=obj;
        newNode->next=top;
        top=newNode;

        cout<<"Part added to inventory\n";
    }

    // pop
    void pop()
    {
        if(top==NULL)
        {
            cout<<"Inventory empty\n";
            return;
        }

        Node* temp=top;

        cout<<"\nPart removed from inventory:\n";
        temp->part.display();

        top=top->next;
        delete temp;
    }

    bool isEmpty()
    {
        return top==NULL;
    }
};

int main()
{
    Stack s;
    int choice;

    do
    {
        cout<<"\n1. Add Part\n";
        cout<<"2. Take Part\n";
        cout<<"3. Exit\n";
        cout<<"Enter choice: ";
        cin>>choice;

        if(choice==1)
        {
            int serial, year, lot;
            Inventory obj;

            cout<<"Enter Serial Number: ";
            cin>>serial;

            cout<<"Enter Manufacture Year: ";
            cin>>year;

            cout<<"Enter Lot Number: ";
            cin>>lot;

            obj.setData(serial, year, lot);

            s.push(obj);
        }
        else if(choice==2)
        {
            s.pop();
        }

    } while(choice!=3);

    cout<<"\nProgram finished\n";

    return 0;
}