#include <iostream>
using namespace std;
class Node
{
public:
    string title;
    double price;
    int edition;
    int pages;
    Node* next;

    Node(string t, double p, int e, int pg)
    {
        title=t;
        price=p;
        edition=e;
        pages=pg;
        next=NULL;
    }
};

class Stack
{
private:
    Node* top;

public:
    Stack()
    {
        top=NULL;
    }


    void push(string t, double p, int e, int pg)
    {
        Node* newNode=new Node(t, p, e, pg);
        newNode->next=top;
        top=newNode;

        cout<<"Book pushed successfully\n";
    }


    void pop()
    {
        if(top==NULL)
        {
            cout<<"Stack is empty\n";
            return;
        }

        Node* temp=top;
        top=top->next;
        delete temp;

        cout << "Book popped successfully\n";
    }


    void peek()
    {
        if(top==NULL)
        {
            cout<<"Stack empty\n";
            return;
        }

        cout<<"\nTop Book:\n";
        cout<<"Title: "<<top->title<<endl;
        cout<<"Price: "<<top->price<<endl;
        cout<<"Edition: "<<top->edition<<endl;
        cout<<"Pages: "<<top->pages<<endl;
    }

    void display()
    {
        if(top==NULL)
        {
            cout<<"Stack empty\n";
            return;
        }

        Node* temp=top;

        cout<<"\nRemaining Books in Stack:\n";

        while(temp!=NULL)
        {
            cout<<"Title: "<<temp->title<<endl;
            cout<<"Price: "<<temp->price<<endl;
            cout<<"Edition: "<<temp->edition<<endl;
            cout<<"Pages: "<<temp->pages<<endl;
            cout<<"-------------------\n";

            temp = temp->next;
        }
    }
};

int main()
{
    Stack s;

    s.push("C++",500,3,400);
    s.push("Java",600,2,350);
    s.push("Python",700,4,450);
    s.push("DSA",800,1,300);
    s.push("AI",900,2,500);


    s.peek();


    s.pop();
    s.pop();


    s.display();

    return 0;
}