#include<iostream>
using namespace std;
int main(){
	
	int arr[5]={11,25,66,81,69};
	
	int n=5;
	for(int i=n-1;i>=0;i--){
		cout<<arr[i]<<" ";
	}
}