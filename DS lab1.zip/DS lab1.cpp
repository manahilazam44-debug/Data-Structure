#include<iostream>
using namespace std;
int main(){
	
    int n;
	cout<<"enter the size of array: ";
	cin>>n;
	
	int arr[n];
	
	cout<<"Enter number of array elements: ";
	for(int i=0;i<n;i++){
	cin>>arr[i];	
}
    int key;
   	cout<<"Enter key: ";
   	cin>>key;
   	
   	bool found=false;
   	int index;
   	
	for(int i=0;i<n;i++){
	if(arr[i]==key){
		found=true;
		index=i;
		break;
	}
}

   if(found){
   	cout<<"Element found in array at index: "<<index; 
   }
   else
   cout<<"Element doesnot found in array"<<endl;
   
   //updation part
   int updateindex,newvalue;
   cout<<"\nEnter index where you wnat to update value: ";
   cin>>updateindex;
   
   cout<<"Enter number: ";
   cin>>newvalue;
   
   arr[updateindex]=newvalue;
   
   cout<<" Array elements after updation: ";
	for(int i=0;i<n;i++){
	cout<<arr[i]<<" ";	
}
   
 }	

