#include <iostream>
using namespace std;

int linearSearch(int arr[], int size, int key, int index){
    if(index == size)
        return -1;

    if(arr[index] == key)
        return index;

    return linearSearch(arr, size, key, index + 1);
}

int main(){
    int arr[]={10, 25, 30, 45, 60, 75};
    int size=6;
    int key;

    cout<<"Enter number to search: ";
    cin>>key;

    int result=linearSearch(arr, size, key, 0);

    if(result!=-1)
        cout<<"Element found at index: "<<result<<endl;
    else
        cout<<"Element not found"<<endl;

    return 0;
}