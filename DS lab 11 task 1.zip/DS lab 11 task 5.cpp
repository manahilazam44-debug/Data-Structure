#include <iostream>
using namespace std;

int sumArray(int arr[], int size){
    if(size == 0)
        return 0;

    return arr[size-1]+sumArray(arr, size-1);
}

int main(){
    int size;

    cout<<"Enter size of array: ";
    cin>>size;

    int arr[100];  

    cout<<"Enter elements of array:\n";
    for(int i = 0; i < size; i++){
        cin>>arr[i];
    }

    int result=sumArray(arr, size);

    cout<<"Sum of array elements is: "<<result<<endl;

    return 0;
}