#include <iostream>
using namespace std;
int main(){
    int tickets[10] ={13579, 26791, 26792, 33445, 55555,
                      62483, 77777, 79422, 85647, 93121};

    int winNumber;
    bool found=false;

    cout<<"Enter this week's winning 5-digit number: ";
    cin>>winNumber;

    if(winNumber<10000 || winNumber>99999){
        cout<<"Invalid number!"<<endl;
        return 0;
    }

    for (int i = 0; i < 10; i++) {
        if (tickets[i] == winNumber) {
            found = true;
            break;
        }
    }

    if(found)
        cout<<"Congratulations! You have a winning ticket."<<endl;
    else
        cout<<"Sorry, no winning ticket this week."<<endl;

    return 0;
}