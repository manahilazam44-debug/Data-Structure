#include <iostream>
using namespace std;

int binarySearch(int arr[], int left, int right, int key) {
    if(left>right)
        return -1; 

    int mid=(left + right)/2;

    if(arr[mid] == key)
        return mid;

    if(key<arr[mid])
        return binarySearch(arr, left, mid-1, key);

    return binarySearch(arr, mid+1, right, key);
}

int main(){
    int arr[]={10, 20, 30, 40, 50, 60};
    int size=6;
    int key;

    cout<<"Enter number to search: ";
    cin>>key;

    int result=binarySearch(arr, 0, size-1, key);

    if(result!=-1)
        cout<<"Found at index: "<<result<<endl;
    else
        cout<<"Not found"<<endl;

    return 0;
}