#include <iostream>
using namespace std;

class Profile{  
public:
    string username;
    int age;
    string bio;
    Profile* next;
};

Profile* head=NULL;

void createProfile(){
    Profile* newProfile=new Profile();

    cout<<"Enter Username: ";
    cin>>newProfile->username;

    cout<<"Enter Age: ";
    cin>>newProfile->age;

    cout<<"Enter Bio: ";
    cin.ignore();
    getline(cin, newProfile->bio);

    newProfile->next=NULL;

    if (head==NULL){
        head=newProfile;
    } 
	else{
        Profile* temp=head;
        while (temp->next!=NULL){
            temp=temp->next;
        }
        temp->next=newProfile;
    }

    cout<<"Profile Created Successfully!\n";
}

Profile* searchProfile(string name){
    Profile* temp=head;

    while(temp!=NULL){
        if(temp->username==name){
            return temp;
        }
        temp=temp->next;
    }

    return NULL;
}

void updateProfile(){
    if(head == NULL){
        cout << "No Profiles Available!\n";
        return;
    }

    string name;
    cout<<"Enter Username to Update: ";
    cin>>name;

    Profile* user=searchProfile(name);

    if (user==NULL){
        cout<<"Profile Not Found!\n";
        return;
    }

    cout<<"Enter New Age: ";
    cin>>user->age;

    cout<<"Enter New Bio: ";
    cin.ignore();
    getline(cin, user->bio);

    cout<<"Profile Updated Successfully!\n";
}

void deleteProfile(){
    if(head==NULL){
        cout<<"No Profiles Available!\n";
        return;
    }

    string name;
    cout<<"Enter Username to Delete: ";
    cin>>name;

    Profile* temp=head;
    Profile* prev=NULL;

    if(temp->username==name){
        head=temp->next;
        delete temp;
        cout<<"Profile Deleted Successfully!\n";
        return;
    }

    while (temp!=NULL && temp->username!=name){
        prev=temp;
        temp=temp->next;
    }

    if (temp==NULL){
        cout<<"Profile Not Found!\n";
        return;
    }

    prev->next=temp->next;
    delete temp;

    cout<<"Profile Deleted Successfully!\n";
}

void viewProfiles(){
    if (head==NULL){
        cout<<"No Profiles Available!\n";
        return;
    }

    Profile* temp=head;

    cout<<"\n--- All Profiles ---\n";

    while(temp!=NULL){
        cout<<"Username: " << temp->username<<endl;
        cout<<"Age: " << temp->age<<endl;
        cout<<"Bio: " << temp->bio<<endl;
        cout<<"---------------------\n";
        temp=temp->next;
    }
}

int main(){
    int choice;

    do{
        cout<<"\n 1. Create Profile";
        cout<<"\n 2. Update Profile";
        cout<<"\n 3. Delete Profile";
        cout<<"\n 4. Search Profile";
        cout<<"\n 5. View All Profiles";
        cout<<"\n 6. Exit";
        cout<<"\n Enter Choice: ";
        cin>>choice;

        if(choice==1)
            createProfile();
        else if(choice==2)
            updateProfile();
        else if(choice==3)
            deleteProfile();
        else if(choice==4){
            string name;
            cout<<"Enter Username to Search: ";
            cin>>name;

            Profile* user=searchProfile(name);

            if(user!=NULL){
                cout<<"Profile Found!\n";
                cout<<"Username: " <<user->username<<endl;
                cout<<"Age: " <<user->age<<endl;
                cout<<"Bio: " <<user->bio<<endl;
            }
			 else{
                cout<<"Profile Not Found!\n";
            }
        }
        else if(choice==5)
            viewProfiles();
        else if(choice==6)
            cout<<"Program Ended\n";
        else
            cout<<"Invalid Choice!\n";

    }
	 while(choice!=6);

    return 0;
}