#include <iostream>
using namespace std;

class Node{
public:
    string brand;
    int units;
    float price;
    Node* next;
};


Node* head=NULL;

void addMobile(){
    Node* newNode=new Node();

    cout<<"Enter Brand: ";
    cin>>newNode->brand;
    cout<<"Enter Units: ";
    cin>>newNode->units;
    cout<<"Enter Price: ";
    cin>>newNode->price;

    newNode->next = NULL;

 
    if(head==NULL) {
        head=newNode;
    }
    else{
        Node* temp=head;
        while (temp->next!=NULL){
            temp=temp->next;
        }
        temp->next=newNode;
    }

    cout<<"Mobile Added!\n";
}

void deleteMobile(){
    if (head==NULL){
        cout<<"List is Empty!\n";
        return;
    }

    string name;
    cout<<"Enter Brand to Delete: ";
    cin>>name;

    Node* temp=head;
    Node* prev=NULL;

    if (temp->brand==name){
        head=temp->next;
        delete temp;
        cout<<"Deleted Successfully!\n";
        return;
    }

    while (temp!=NULL && temp->brand!=name){
        prev=temp;
        temp=temp->next;
    }

    if (temp==NULL){
        cout<<"Brand Not Found!\n";
        return;
    }

    prev->next=temp->next;
    delete temp;

    cout <<"Deleted Successfully!\n";
}

void display(){
    if (head==NULL){
        cout<<"No Mobiles Available!\n";
        return;
    }

    Node* temp = head;
    cout<<"\n--- Inventory ---\n";

    while (temp!=NULL){
        cout << "Brand: " <<temp->brand<<endl;
        cout << "Units: " <<temp->units<<endl;
        cout << "Price: " <<temp->price<<endl;
        cout << "------------------\n";
        temp=temp->next;
    }
}

int main() {
    int choice;
    do {
        cout << "\n1. Add";
        cout << "\n2. Delete";
        cout << "\n3. Display";
        cout << "\n4. Exit";
        cout << "\nEnter Choice: ";
        cin >> choice;

        if (choice==1)
            addMobile();
        else if (choice==2)
            deleteMobile();
        else if (choice==3)
            display();
        else if (choice==4)
            cout << "Program Ended\n";
        else
            cout << "Invalid Choice!\n";

    } while (choice!=4);

    return 0;
}