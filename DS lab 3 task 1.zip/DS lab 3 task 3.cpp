#include<iostream>
using namespace std;
struct Product{
	string name;
	int code;
	double price;
};
void displayInfo(Product p[], int size){
	cout<<"**********Your Products***********"<<endl;
	for(int i=0; i<size; i++){
		cout<<"Name: "<<p[i].name<<endl;
		cout<<"Code: "<<p[i].code<<endl;
		cout<<"Price: "<<p[i].price<<endl;
		cout<<endl;
		
	}
}
int main(){
	int size;
	cout<<"Total number of products: ";
	cin>>size;
	
	Product* p= new Product[size];
	for(int i=0; i<size; i++){
		
		cout<<"Products: " <<i+1<<endl;
		
		cout<<"Name: ";
		cin>>p[i].name;
		
		cout<<"Code: ";
		cin>>p[i].code;
		
    	cout<<"Price: ";
		cin>>p[i].price;
		
		cout<<endl;
	}
	
	displayInfo(p, size);
	delete p;
}