#include<iostream>
using namespace std;
int main(){
   int row, col;
   
   cout<<"Enter no of rows: "<< endl;
   cin>>row;
   
   cout<<"Enter no of coloums: "<<endl;
   cin>>col;
   
   int** matrix= new int *[row];
   
   for(int i=0; i<row; i++){
   	matrix[i]= new int[col];
   }
	
	 cout<<"Enter elements of the matrix:"<<endl;
    for (int i=0; i<row; i++) {
        for (int j=0; j<col; j++) {
            cin>> matrix[i][j];
        }
    }
    
      cout<<"Matrix:"<<endl;
    for (int i=0; i<row; i++) {
        for (int j=0; j<col; j++) {
            cout<< matrix[i][j] << " ";
        }
        cout<<endl;
    }
    
     for (int i=0; i<row; i++) {
        delete[] matrix[i];  
    }
    
    delete [] matrix;
    matrix= nullptr;
    
    return 0;
}